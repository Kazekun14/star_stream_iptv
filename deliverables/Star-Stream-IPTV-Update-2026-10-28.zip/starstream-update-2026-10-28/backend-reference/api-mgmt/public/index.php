<?php
 
declare(strict_types=1);
 
require __DIR__ . '/../vendor/autoload.php';

use StarStream\Core\App;

App::run();
